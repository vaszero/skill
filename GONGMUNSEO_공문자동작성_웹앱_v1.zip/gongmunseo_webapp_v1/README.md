
# GONGMUNSEO 공문 자동작성 웹앱 v1

한국 기관·공공업무용 공문 초안 작성 + HWPX 한글문서 저장용 Streamlit 앱입니다.

## 주요 기능
- 대외 공문
- 내부 기안
- 계획서
- 결과보고서
- 회의록
- GONGMUNSEO 원칙 적용
- AI 없이도 규칙 기반 초안 생성
- OpenAI API를 연결하면 문장 다듬기/초안 생성
- 생성 결과를 `.hwpx` 한글문서로 저장

## 실행 방법

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

브라우저에서 안내된 로컬 주소를 열면 됩니다.

## AI 기능 사용
AI 기능은 선택입니다. 기본 상태에서는 API 없이 규칙 기반으로 동작합니다.

배포 환경에서는 `.streamlit/secrets.toml`에 아래처럼 넣는 방법을 권장합니다.

```toml
OPENAI_API_KEY = "sk-..."
```

실제 키가 들어간 `secrets.toml`은 GitHub에 올리지 마세요.

## HWPX
`python-hwpx`를 이용해 새 HWPX 문서를 생성합니다.
현재 v1은 **범용 문서**를 생성합니다.

기관에서 실제 사용하는 HWPX 공문 양식을 그대로 유지하면서 특정 위치에 내용을 채우려면
해당 기관의 `.hwpx` 템플릿 파일을 확보한 뒤 v2에서 템플릿 채움 방식으로 확장하는 것이 좋습니다.

## 배포
가장 쉬운 방법:
1. 이 폴더를 GitHub 저장소에 업로드
2. Streamlit Community Cloud에서 저장소 연결
3. Main file path를 `app.py`로 지정
4. 필요하면 Secrets에 `OPENAI_API_KEY` 등록

## 보안
- API Key를 코드에 직접 쓰지 마세요.
- 민감한 개인정보/의료정보/주민등록번호 등이 포함된 문서는 외부 AI API 사용 전에 기관 정책을 확인하세요.
- 생성 문서는 발송 전 사람이 최종 검수해야 합니다.
