
import os
import re
import tempfile
from pathlib import Path
from datetime import date

import streamlit as st

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

try:
    from hwpx import HwpxDocument
except Exception:
    HwpxDocument = None


st.set_page_config(
    page_title="GONGMUNSEO · 공문 자동작성",
    page_icon="📝",
    layout="wide",
)

GONGMUNSEO_RULES = """
당신은 한국 기관·공공업무의 행정문서 작성 도우미다.
공문, 내부기안, 계획서, 결과보고서, 회의록, 안내·통지문을
검토·결재·발송 가능한 행정문서 초안으로 구조화한다.

핵심 원칙:
1. 사용자가 제공한 사실만 확정 정보로 사용한다.
2. 필수 정보가 없으면 추측하지 말고 [확인 필요]로 표시한다.
3. 제목은 문서 목적이 한눈에 보이게 작성한다.
4. 본문은 결론과 요청사항이 빨리 보이도록 구성한다.
5. 항목 체계가 필요하면 1. → 가. → 1) → 가) 순으로 일관되게 쓴다.
6. 날짜, 시간, 요일, 인원, 금액, 연락처, 제출기한, 장소를 다시 검수한다.
7. 붙임이 있으면 본문에서 언급하고 하단에 '붙임'을 정리한다.
8. 대외 공문은 필요 시 마지막에 '끝.'을 둔다.
9. 짧고 객관적이며 행정적으로 명확하게 쓴다.
10. 법령명, 조문, 사업명, 기관명, 실적을 임의로 만들지 않는다.

문서별 기본 구조:
- 대외 공문: 제목 → 근거/배경 → 주요 내용 → 협조·요청사항 → 기한/문의 → 붙임 → 끝.
- 내부 기안: 제목 → 목적 → 추진배경 → 주요 내용 → 일정/예산/담당 → 검토·결재 요청
- 계획서: 추진배경 → 목적 → 사업개요 → 세부내용 → 추진일정 → 역할분담 → 예산 → 기대효과 → 행정사항
- 결과보고서: 개요 → 추진내용 → 실적 → 주요성과 → 문제점/개선사항 → 향후계획 → 붙임
- 회의록: 회의명 → 일시 → 장소 → 참석자 → 안건 → 논의내용 → 결정사항 → 담당자/기한 → 차기 일정
"""

DOC_STRUCTURES = {
    "대외 공문": ["근거/배경", "주요 내용", "협조·요청사항", "기한/문의", "붙임", "끝."],
    "내부 기안": ["목적", "추진배경", "주요 내용", "일정/예산/담당", "검토·결재 요청"],
    "계획서": ["추진배경", "목적", "사업개요", "세부내용", "추진일정", "역할분담", "예산", "기대효과", "행정사항"],
    "결과보고서": ["개요", "추진내용", "실적", "주요성과", "문제점/개선사항", "향후계획", "붙임"],
    "회의록": ["회의명", "일시", "장소", "참석자", "안건", "논의내용", "결정사항", "담당자/기한", "차기 일정"],
}


def clean_filename(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|]+', "_", (name or "").strip())
    name = re.sub(r"\s+", "_", name)
    return (name[:80] or "공문초안")


def as_confirmed(value: str) -> str:
    value = (value or "").strip()
    return value if value else "[확인 필요]"


def build_template_draft(data: dict) -> str:
    """AI 키가 없어도 동작하는 규칙 기반 초안."""
    doc_type = data["문서 종류"]
    title = as_confirmed(data["제목"])
    lines = [title, ""]

    if data["수신처"]:
        lines += [f"수신: {data['수신처']}", ""]

    if doc_type == "대외 공문":
        lines += [
            f"1. 근거/배경: {as_confirmed(data['근거/배경'])}",
            f"2. 주요 내용: {as_confirmed(data['핵심 내용'])}",
            f"3. 협조·요청사항: {as_confirmed(data['요청사항'])}",
            f"4. 일정/장소: {as_confirmed(data['일정/장소'])}",
            f"5. 문의: {as_confirmed(data['담당부서/담당자'])}",
        ]
        if data["붙임"]:
            lines += ["", f"붙임  {data['붙임']}  1부."]
        lines += ["", "끝."]

    elif doc_type == "내부 기안":
        lines += [
            f"1. 목적: {as_confirmed(data['목적'])}",
            f"2. 추진배경: {as_confirmed(data['근거/배경'])}",
            f"3. 주요 내용: {as_confirmed(data['핵심 내용'])}",
            f"4. 일정/예산/담당: {as_confirmed(data['일정/장소'])} / {as_confirmed(data['예산'])} / {as_confirmed(data['담당부서/담당자'])}",
            f"5. 검토·결재 요청: 위와 같이 추진하고자 하오니 검토하여 주시기 바랍니다.",
        ]

    elif doc_type == "계획서":
        lines += [
            f"1. 추진배경\n  가. {as_confirmed(data['근거/배경'])}",
            f"2. 목적\n  가. {as_confirmed(data['목적'])}",
            f"3. 사업개요\n  가. 사업명: {title}\n  나. 일정/장소: {as_confirmed(data['일정/장소'])}",
            f"4. 세부내용\n  가. {as_confirmed(data['핵심 내용'])}",
            f"5. 추진일정\n  가. {as_confirmed(data['일정/장소'])}",
            f"6. 역할분담\n  가. 담당: {as_confirmed(data['담당부서/담당자'])}",
            f"7. 예산\n  가. {as_confirmed(data['예산'])}",
            f"8. 기대효과\n  가. {as_confirmed(data['기대효과'])}",
            f"9. 행정사항\n  가. {as_confirmed(data['요청사항'])}",
        ]

    elif doc_type == "결과보고서":
        lines += [
            f"1. 개요\n  가. {as_confirmed(data['목적'])}",
            f"2. 추진내용\n  가. {as_confirmed(data['핵심 내용'])}",
            f"3. 실적\n  가. {as_confirmed(data['실적'])}",
            f"4. 주요성과\n  가. {as_confirmed(data['주요성과'])}",
            f"5. 문제점 및 개선사항\n  가. {as_confirmed(data['개선사항'])}",
            f"6. 향후계획\n  가. {as_confirmed(data['향후계획'])}",
        ]
        if data["붙임"]:
            lines += ["", f"붙임  {data['붙임']}  1부."]

    else:  # 회의록
        lines += [
            f"1. 회의명: {title}",
            f"2. 일시: {as_confirmed(data['일정/장소'])}",
            f"3. 장소: {as_confirmed(data['장소'])}",
            f"4. 참석자: {as_confirmed(data['참석자'])}",
            f"5. 안건: {as_confirmed(data['목적'])}",
            f"6. 논의내용\n  가. {as_confirmed(data['핵심 내용'])}",
            f"7. 결정사항\n  가. {as_confirmed(data['요청사항'])}",
            f"8. 담당자/기한: {as_confirmed(data['담당부서/담당자'])}",
            f"9. 차기 일정: {as_confirmed(data['향후계획'])}",
        ]

    return "\n".join(lines)


def build_ai_draft(data: dict, api_key: str, model: str) -> str:
    if OpenAI is None:
        raise RuntimeError("openai 패키지가 설치되지 않았습니다.")
    client = OpenAI(api_key=api_key)

    user_info = "\n".join([f"- {k}: {v if str(v).strip() else '[미입력]'}" for k, v in data.items()])
    prompt = f"""
{GONGMUNSEO_RULES}

아래 정보로 '{data["문서 종류"]}' 초안을 작성하라.

[사용자 입력]
{user_info}

[출력 규칙]
- 최종 문서 본문만 출력한다.
- 제공되지 않은 사실은 만들지 말고 [확인 필요]로 표시한다.
- 불필요하게 장황하게 쓰지 않는다.
- 문서 종류에 맞는 번호 체계를 사용한다.
- 제목을 첫 줄에 둔다.
- 대외 공문은 붙임이 있으면 붙임을 정리하고 필요 시 '끝.'으로 마무리한다.
"""
    response = client.responses.create(
        model=model,
        input=prompt,
    )
    return response.output_text.strip()


def create_hwpx_bytes(title: str, body: str, institution: str = "") -> bytes:
    if HwpxDocument is None:
        raise RuntimeError(
            "python-hwpx 패키지가 설치되지 않았습니다. requirements.txt로 설치 후 다시 실행하세요."
        )

    doc = HwpxDocument.new()
    if institution.strip():
        doc.add_paragraph(institution.strip())
    doc.add_heading(title.strip() or "공문 초안", level=1)

    for raw_line in body.splitlines():
        line = raw_line.rstrip()
        if not line:
            doc.add_paragraph("")
        else:
            doc.add_paragraph(line)

    with tempfile.TemporaryDirectory() as tmpdir:
        out = Path(tmpdir) / f"{clean_filename(title)}.hwpx"
        doc.save_to_path(str(out))
        return out.read_bytes()


st.markdown("""
<style>
.block-container {padding-top: 1.6rem; padding-bottom: 3rem;}
[data-testid="stMetricValue"] {font-size: 1.3rem;}
.small-note {color:#666; font-size:0.9rem;}
</style>
""", unsafe_allow_html=True)

st.title("📝 GONGMUNSEO · 공문 자동작성")
st.caption("공문 내용을 입력하면 GONGMUNSEO 작성 원칙으로 초안을 만들고, HWPX 한글문서로 저장합니다.")

with st.sidebar:
    st.header("설정")
    use_ai = st.toggle("AI로 문장 다듬기", value=False)
    model = st.selectbox(
        "AI 모델",
        ["gpt-5.6-luna", "gpt-5.6-terra", "gpt-5.6-sol"],
        index=0,
        disabled=not use_ai,
        help="비용을 아끼려면 Luna부터 시작하는 것을 권장합니다.",
    )

    secret_key = ""
    try:
        secret_key = st.secrets.get("OPENAI_API_KEY", "")
    except Exception:
        pass
    env_key = os.getenv("OPENAI_API_KEY", "")
    api_key = secret_key or env_key

    if use_ai and not api_key:
        api_key = st.text_input(
            "OpenAI API Key",
            type="password",
            help="테스트용입니다. 배포 시에는 Streamlit Secrets에 저장하세요.",
        )

    st.divider()
    st.markdown("**1차 버전 범위**")
    st.write("• 대외 공문")
    st.write("• 내부 기안")
    st.write("• 계획서")
    st.write("• 결과보고서")
    st.write("• 회의록")
    st.caption("기관 고유 HWPX 양식에 정확히 끼워 넣는 기능은 실제 기관 템플릿을 받은 뒤 2차 버전에서 적용합니다.")


left, right = st.columns([1, 1])

with left:
    st.subheader("1. 기본 정보")
    doc_type = st.selectbox("문서 종류", list(DOC_STRUCTURES.keys()))
    institution = st.text_input("기관명", placeholder="예: ○○시 정신건강복지센터")
    recipient = st.text_input("수신처", placeholder="예: 관내 유관기관장")
    title = st.text_input("제목*", placeholder="예: 2026년 생성형 AI 실무교육 참석 협조 요청")
    purpose = st.text_area("목적", height=90, placeholder="이 문서를 보내는 이유")
    basis = st.text_area("근거/배경", height=90, placeholder="관련 사업, 추진 배경, 기존 협의사항 등")
    core = st.text_area("핵심 내용*", height=160, placeholder="반드시 들어가야 하는 사실을 메모하듯 입력하세요.")

with right:
    st.subheader("2. 세부 정보")
    schedule = st.text_input("일정/장소", placeholder="예: 2026. 10. 15.(목) 14:00 / ○○교육장")
    place = st.text_input("장소", placeholder="회의록에서 별도 장소가 필요할 때")
    budget = st.text_input("예산", placeholder="예: 금500,000원 / 해당 없음")
    request = st.text_area("요청·결정사항", height=95, placeholder="상대방에게 요청할 내용 또는 회의 결정사항")
    manager = st.text_input("담당부서/담당자/연락처", placeholder="예: 교육팀 홍길동 / 033-000-0000")
    attachments = st.text_input("붙임", placeholder="예: 교육 안내문 1부")
    attendees = st.text_input("참석자", placeholder="회의록용")
    results = st.text_input("실적", placeholder="결과보고서용")
    achievements = st.text_input("주요성과", placeholder="결과보고서용")
    improvement = st.text_input("문제점/개선사항", placeholder="결과보고서용")
    next_plan = st.text_input("향후계획", placeholder="결과보고서·회의록용")
    expected = st.text_input("기대효과", placeholder="계획서용")

data = {
    "문서 종류": doc_type,
    "기관명": institution,
    "수신처": recipient,
    "제목": title,
    "목적": purpose,
    "근거/배경": basis,
    "핵심 내용": core,
    "일정/장소": schedule,
    "장소": place,
    "예산": budget,
    "요청사항": request,
    "담당부서/담당자": manager,
    "붙임": attachments,
    "참석자": attendees,
    "실적": results,
    "주요성과": achievements,
    "개선사항": improvement,
    "향후계획": next_plan,
    "기대효과": expected,
}

st.divider()

if "draft" not in st.session_state:
    st.session_state.draft = ""

c1, c2, c3 = st.columns([1, 1, 2])

with c1:
    generate = st.button("✨ 공문 초안 만들기", type="primary", use_container_width=True)
with c2:
    clear = st.button("초기화", use_container_width=True)
with c3:
    st.caption("AI를 끄면 무료 규칙 기반 초안이 생성됩니다. AI를 켜면 API 사용료가 별도로 발생할 수 있습니다.")

if clear:
    st.session_state.draft = ""
    st.rerun()

if generate:
    if not title.strip():
        st.warning("제목은 입력해 주세요.")
    elif not core.strip() and doc_type not in ["회의록"]:
        st.warning("핵심 내용은 입력해 주세요.")
    else:
        try:
            with st.spinner("GONGMUNSEO 규칙으로 문서를 작성하는 중입니다..."):
                if use_ai:
                    if not api_key:
                        st.warning("AI를 사용하려면 API Key가 필요합니다. AI를 끄면 규칙 기반으로 바로 만들 수 있습니다.")
                    else:
                        st.session_state.draft = build_ai_draft(data, api_key, model)
                else:
                    st.session_state.draft = build_template_draft(data)
        except Exception as e:
            st.error(f"초안 생성 중 오류가 발생했습니다: {e}")
            st.info("AI를 끄고 규칙 기반 초안으로 다시 시도할 수 있습니다.")

if st.session_state.draft:
    st.subheader("3. 생성된 초안")
    edited = st.text_area(
        "초안을 직접 수정한 뒤 HWPX로 저장할 수 있습니다.",
        value=st.session_state.draft,
        height=520,
        key="draft_editor",
    )
    st.session_state.draft = edited

    d1, d2 = st.columns([1, 1])
    with d1:
        st.download_button(
            "📄 TXT로 저장",
            data=edited.encode("utf-8"),
            file_name=f"{clean_filename(title)}.txt",
            mime="text/plain",
            use_container_width=True,
        )

    with d2:
        if HwpxDocument is None:
            st.error("현재 실행 환경에 python-hwpx가 없어 HWPX 생성을 사용할 수 없습니다.")
        else:
            try:
                hwpx_data = create_hwpx_bytes(title, edited, institution)
                st.download_button(
                    "🟦 HWPX 한글문서로 저장",
                    data=hwpx_data,
                    file_name=f"{clean_filename(title)}.hwpx",
                    mime="application/hwp+zip",
                    use_container_width=True,
                )
            except Exception as e:
                st.error(f"HWPX 생성 오류: {e}")

st.divider()
st.markdown(
    """
    <div class="small-note">
    <b>주의:</b> 이 앱은 초안 작성 도구입니다. 법령·공고·사업근거·개인정보·금액·일정은
    발송 전 담당자가 반드시 원문과 대조해 검수하세요.
    </div>
    """,
    unsafe_allow_html=True,
)
